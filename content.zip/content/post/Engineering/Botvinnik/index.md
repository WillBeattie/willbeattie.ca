---
title: "Botvinnik"
date: 2015-06-03T22:49:16-04:00
draft: true
categories: ["Engineering"]
status: "Shelved"
image: "/EarlyCAD.jpg"
desc: "Tired of losing to a chess computer on a computer?  Botvinnik is a chess playing robot based off of OpenCV, Stockfish, and a SCARA II type arm, so you can lose to a computer in real life!"
---

I play too much chess. I took up the game about a year ago and have been studying and playing frequently since, exclusively online. I'd like to get used to playing on a real board, but finding a partner is tough. In a moment of maximum introversion, I decided to build a robotic opponent instead of making friends. The tentative project name is Bot-vinnik, in honor of the only former world champion with an easy-to-pun name.

{{<figure src="/human.jpg#center" caption="Mikhail Botvinnik: 3 time world champion, 0% robot">}}

Playing chess is a neat application for robotics, and while it might seem complicated, the project breaks down nicely into four not-so-crazy modules:

*   A pick-n-place style arm to move the chess pieces
*   A vision system to identify moves made by the human opponent
*   A chess engine to descide what move to make in response
*   A communication/controls interface to link it all together

{{<youtube 2fQpZCamuBs>}}
Vladimir Kramnik playing an industrial robot arm. I think they drew.

_Pick-n-Place Arm_

This arm is likely to be the most difficult component of the project. Luckily, the functional requirements of this module are considerably easier than most robotics applications. The workspace isn't huge, the only motion needed is translation, and the pieces are relatively large, light, and spaced apart from each other.

Functional requirements:

*   3 degrees of freedom movement (x,y,z)
*   Workspace of 45x45x20 cm
*   Minimum accuracy across workspace of +/- 0.25"
*   Maximum load >100g
*   Able to complete a chess move in < 5s

_Computer vision_

This module will be a bit of a foray into the unknown for me. The basic idea is to fix a webcam on a retort stand or some other elevated position, and use it to determine the state of the board. My intention is to use OpenCV for my processing needs. A chess board has nice crisp lines and contrasting colors that should make registering the board position/orientation a breeze. What isn't clear is whether I'll be able to correctly differentiate between the different types of pieces. Even if that isn't possible, I should be able to work around it by comparing the state of the board to the state of the board on the previous move - what square that was occupied is now empty, what square that was empty (or filled with a piece of another color) is now occupied.

{{<figure src="/Vision Task.jpg#center" caption="The computer vision task is to take a picture and turn it into a string representing the position">}}

Chess is a game full of peculiarities that make this task harder than it would initially appear. The state of the game isn't determined entirely by the position on the board. The act of castling, capturing en passant, and drawing by repetition and the 50 move rule all depend on knowledge of the previous moves of the game, so I'll have to put some thought into how this gets recorded as the game gets played out.

Functional requirements:

*   Determine which squares are occupied by a piece
*   Determine the color of each piece
*   Optional: determine the type (pawn, bishop, etc.) of each piece

_Chess Engine_

A chess engine is a piece of software that takes in a game state (called a position in chess), evaluates it, and produces a suggestion for what it thinks is the best move. If I were creating something from scratch, this would be a monstrous component of the project. Luckily, the best chess on the planet is currently played by an open source engine called [Stockfish](https://stockfishchess.org/). Lucky! I've used Stockfish inside other applications before, but I've never had to interact with the code itself. If I can get an interface up and running for communicating with it, this module should be easy.

Functional requirements:

*   Produce move suggestions when queried with a position
*   Optional: adjustable difficulty rating

{{<figure src="/stockfish.jpg#center" caption="Striking fear into the hearts of chess players everywhere">}}

_Controls/communications_

Like most good mechatronic projects, Bot-vinnik needs a brain to tie all the pieces together into something functional. In this case I'll have two computers running: a laptop taking care of the image processing and chess engine, and a microcontroller sending commands to the actuators on the robot arm.

{{<figure src="/Flow Chart.jpg#center" caption="A flow chart showing the different modules of the system and the ways in which they're connected">}}