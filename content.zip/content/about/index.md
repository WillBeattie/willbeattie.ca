---
title: "About Me"
date: 2018-04-28T16:10:23-04:00
draft: true
---

I'm a Canadian R&D engineer and tinkerer.  I'm interested in robotics and automation, instrumentation, biomedical device design and million other things. In my free time I like to get outside (mostly climbing and hiking) and making stuff at [Site 3 Colaboratory](http://www.site3.ca/)

{{<figure src="/will.jpg">}}

You can see my résumé [here](/Résumé - Beattie.pdf).

This site was built with the [Hugo](https://gohugo.io/) static site engine, using a tweaked version of the [Nederburg](https://github.com/appernetic/hugo-nederburg-theme) theme.  As a non-developer it took a bit of trial and error to get it working the way I wanted, but Hugo is pretty flexible and really friggin fast.

