---
title: "Outdoors"
date: 2018-04-03T21:41:37-04:00
draft: true
type: "category-desc"
image: "/Manatee - Glacier.jpg"
---

Trip reports from time spent outside