---
title: "Twitch Design"
date: 2018-04-03T22:50:30-04:00
draft: true
categories: ["Engineering"]
tags: ["Twitch"]
---

I built this project out of my house, where I'm limited to a chopsaw and some hand tools. These constraints necessitated serious Design-For-Manufacture consideration, but the rise of public-access rapid prototyping tools has made it easier than ever to [get things built](http://www.instructables.com/id/How-to-Build-your-Everything-Really-Really-Fast/). Here, again, was my final CAD design.

{{<figure src="/GrabCAD Rendering.JPG" caption="CAD view of the unwired robot"  >}}


Twitch is an aluminium sandwich. The [plate and spacer](http://www.instructables.com/id/How-to-Build-your-Everything-Really-Really-Fast/step9/Joining-Parallel-Plates-Using-Standoffs-and-Spacer/) method of construction is fast, easy, and great for aligning features on the top plate with features on the bottom. This last point was key, as alignment and accuracy are crucial if my linkages were to move.

The mobility of a planar linkage assembly is given by M=3(N-1)-2*j, where N is the number of links and j is the number of revolute joints. Each mechanism in the robot has N=5 links and j=6 revolute joints, so the equation says M = 0. What lets the mechanism move is the fact that the middle link is identical to the outer two in size and orientation. It's completely degenerate and therefore doesn't count. So N=4, j=4, and M=1 degree of freedom just like we want. It's therefore critical that I get the length and location of all links and joints as precise as possible - too much error and my mechanism doesn't move.

{{< figure src="/linkage.JPG" caption="Both systems have 5 links and 6 joints, but the middle joint of the left assembly is degenerate, allowing the system to move"  >}}

I had the frame and linkage bars cut for me on a waterjet, a rapid prototyping tool that perfectly fit my needs. First, the waterjet has no problems cutting strange shapes like my linkage arms. Second, it is a high precision process, so the mounting holes cut into the frame would ensure all my internal components were well aligned. Third, it's completely hands off. I just uploaded my design to the good people at [Big Blue Saw](https://www.bigbluesaw.com/), and for ~$150 the parts were on my doorstep.

{{< figure src="/Frame.JPG" caption="Parts from Big Blue Saw. Here I had already installed the pegs on which the motor assemblies would ride, as well as one of the two servos"  >}}

Once I had the frame and fasteners I needed (purchased largely from [Fastenal](https://www.fastenal.com/home)), the only other tricky components to manufacture were the UHMW blocks to be attached to the gearboxes.

{{< figure src="/Base block w link hole.jpg" caption="Drawing for the base block. Four countersunk holes accept bolts to attach the gearbox, a central hole accepts the peg about which the motor assembly rotates, and a small off-centre hole accepts the shoulder screw that attaches the linkage bar."  >}}

I trimmed the sheet of UHMW bar stock down to size with a chopsaw, surprisingly managing to keep a +/- .017" tolerance - horrible for machining, but probably OK for me. I carefully marked out hole locations using my callipers, then borrowed a small drill press from the [Toronto Tool Library](http://torontotoollibrary.com/). UHMW is very machinable, so drilling proved quite straightforward. Once the blocks were complete the rest of the robot came together like a kit.

{{< figure src="/Linkage View.JPG" caption="View of the frame with the complete motor assemblies and linkages"  >}}

Next came electrical assembly. Since I have wired components attached to the roof (battery, Arduino, servo #1) and to the floor (motor controllers, servo #2), I used a clamshell style system where all floor-to-roof connections were made along one edge of the robot.

As you can see, it's not the prettiest setup in the world. I completely neglected cable management in the design phase, and ended up haphazardly drilling in holes to accept twist-ties to hold wires in place. Next time I'll know better!

{{< figure src="/Wiring.jpg" caption="The robot folded open shows the lamentable state of wiring inside. Alas."  >}}

For those looking to make or mod your own, you can download the full set of CAD files [on GrabCAD](https://grabcad.com/library/twitch-1).