---
title: "Engineering"
date: 2018-04-28T16:10:23-04:00
draft: true
type: "category-desc"
image: "/Food Colored Device.jpg"
---

Design and build reports from my engineering projects, both personal and professional/academic