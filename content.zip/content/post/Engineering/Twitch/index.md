---
title: "Twitch"
date: 2014-04-10T22:50:10-04:00
draft: true
categories: ["Engineering"]
tags: ["Twitch"]
type: "post"
image: "/LinkageAnimation.gif"
status: "Complete"
desc: "Twitch is a small RC vehicle. I built is as a study in an unusual drive train, and also as a very expensive toy. It uses omniwheels coupled with a linkage rod and a giant servo to swap its wheel orientation on demand"
---

Twitch is a small RC vehicle. I built is as a study in an unusual drive train, and also as a very expensive toy. The vehicle is quite close to a clone of [Shane Colton's](http://scolton.blogspot.ca) project [Twitch Jr.](http://scolton.blogspot.ca/search/label/twitch), which itself was inspired by a FIRST Robotics team's bot Twitch. So I guess that makes mine the third generation.

So, beyond being a box with four wheels that moves, what is Twitch? Two critical features make this thing fun to drive: 1) Omniwheels, allowing the wheels to slide sideways without skidding, 2) A motor and wheel configuration that allows the wheel direction to swing from front-to-back to side-to-side.  The black boxes in the animation below are high-torque servos that drive the pivoting of the wheel and motor assemblies

{{<figure src="/LinkageAnimation.gif#center" caption="Showing the motion of the linkages">}}

<!---
<video width="320" class="center" autoplay loop>
  <source src="/Linkage Animation.mp4" type="video/mp4">
Your browser does not support the video tag.
</video>
-->

The result is a control system that I'll call 'holonom-ish.' It doesn't exactly have a degree of control for every degree of freedom (x,y and theta), but it doesn't have the same problems with manoeuvres like parallel parking that a conventional 4wd vehicle does. As a result it's very manoeuvrable and extremely fun to drive.

{{< youtube Tv6HHWsS-_I >}}
Video from my in-progress robot shows how silly and fun to drive it is.

This is my first just-for-fun robot, and it was built without access to a machine shop. Accordingly, I kept the design as simple as I could and borrowed ideas wherever possible. I'll go over the robot's fabrication, and construction in the following pages.

{{<figure src="/Twitch.JPG#center" caption="The robot in its current form"  >}}

Curious parties can download the [bill of materials](./Final BOM.pdf) and all of the [CAD files](https://grabcad.com/library/twitch-1) and go build your own!.