---
title: "Double-Gusset Shoulder Bag"
date: 2014-06-03T22:21:07-04:00
draft: true
categories: ["Arts and Crafts"]
tags: ["Leatherwokring"]
image: "/415.jpg"
desc: "A very large shoulder-bag in brown veg-tan with a floral lining"
---
This was my largest project to date. My cousin requested a lined shoulder bag but was looking for something larger than the messenger bag I made for my sister. Starting from scratch is a difficult thing - most of my other projects are closely based off of existing designs if not direct ripoffs. A good starting point came from watching the movie Marathon Man, where the love interest has a very nice bag that seemed to meet my cousin's needs.
{{<figure  src="/Marathon Man.jpg#center" caption="Is it safe?">}}
So the design plan was to use two gussets and an internal divider. This gives two internal compartments: a larger main area and a smaller slot at the front for documents and the like. After sketching some pieces out on Inventor I made a scale model out of paper to test the dimensions and made some adjustments based on its look. I've found this practice especially helpful in working with 3D projects. It can be very difficult to predict what aspect ratios will look 'right' and which will just be visually unappealing.
{{<figure  src="/Paper Model.jpg" caption="I ended up dramatically decreasing the depth of the main compartment. It's pretty clear that it is too large here">}}

The construction process was laborious, as expected. Most of the design choices were made as I went along (not the best approach!), particularly with respect to the closure and the strap. I decided to make the closure with a strap and a metal keep, as seen in the [Nigel Armitage messenger bag](https://www.youtube.com/watch?v=nEwbvfsZfBw) demonstration. I later regretted this decision as the leather to which the keep was attached wouldn't stay straight at rest - it tended to buckle inwards, making it rather difficult to fold the flap over top of the keep. Closing the bag is pretty much always a two handed operation. So, for next time I won't adopt this closure unless the front piece is considerably smaller and less prone to buckling.

{{<figure src="/412.jpg#center" caption="The finished bag">}}

{{<figure src="/415.jpg#center" caption="Side view.  The strap is attached permanently with a line of stitching and a single copper rivet">}}

{{<figure src="/424.jpg#center" caption="The entire inside of the bag is lined with a fabric of my cousin's selection. The fabric is folded over at the leather's edge to make for a nice appearance.">}}

{{<figure src="/JBag 3.jpg#center" caption="The divider (made of 2oz low grade Tandy leather) has a few pockets for pens and electronics.">}}

I'm pretty pleased with how it turned out, despite a few imperfections in the leather and the occasional bit of wonky stitching. It has certainly encouraged me to take on making a briefcase for myself.

**Leather:**

*   Herman Oak 5-6 oz veg tan (front, back, and strap)
*   Herman Oak 3-4 oz veg tan (both gussets)
*   Crap grade Tandy 2-3oz veg-tan (divider, interior pockets)

**Details:**

*   Thread: [0.035" Maine Waxed Cord in Tan](http://www.mainethread.com/product9.html)
*   Dye: [Fiebing's light brown](https://www.tandyleatherfactory.ca/en-cad/home/department/leather-dye/fiebings-leather-dye/2100-05.aspx)
*   Closure: [Strap and strap loop](https://www.tandyleatherfactory.ca/en-cad/search/searchresults/11406-03.aspx)
*   Lining: Cotton. The pattern is [here](http://www.myfabricspot.com/botanique-bold-bouquet-in-asparagus.html)

**Approximate bill of materials:**

*   Leather - ~5 sqft at an average cost of $12/sqft = $60
*   Strap buckle = $3
*   Dye - maybe half a bottle at $7/bottle = $4
*   Strap loop for closure = $4
*   Lining - 1/2 yard at $11/yard = $6

The total cost of the project was ~$75