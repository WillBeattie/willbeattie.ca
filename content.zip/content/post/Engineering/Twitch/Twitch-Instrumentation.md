---
title: "Twitch Instrumentation"
date: 2018-04-03T22:51:01-04:00
draft: true
categories: ["Engineering"]
tags: ["Twitch"]
image: "/Twitch.JPG"
---


Part of what separates a robot from an RC car is its instrumentation. As you can probably tell from my [driving videos](./Videos.html), Twitch isn't the easiest thing to handle. It's my intention to gradually outfit the car with instrumentation to facilitate both fully autonomous and assisted driving. This is the main direction of work-in-progress on this project right now.

**Gyroscope assisted stabilization**
{{<youtube NiuACKS0CIc>}}

It's awfully tough to keep Twitch pointed in a straight line. Especially on rough terrain, I'm constantly trying to correct the course of the robot through the joystick, but this gets in the way of actually driving.

Closed loop yaw rate control helps mitigate this problem. Using a simple [PI controller](https://en.wikipedia.org/wiki/PID_controller), the microprocessor onboard alters the commands sent to the motors in order to try to match the requested yaw rate to the yaw rate measured by a gyroscope onboard.

**Autonomous and assisted driving**

In the near future I plan on installing a webcam and one or two ultrasonic distance sensors mounted on servo motors. I'd love to be able to enter an assisted-driving mode for drifting in circles around an object. As seen in my early videos, maintaining a consistent radius and keeping centred around an object is tough for a human driver to do, but I suspect this manoeuvre is an excellent candidate for a closed loop system.