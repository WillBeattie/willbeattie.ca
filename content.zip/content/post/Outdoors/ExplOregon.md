---
title: "Rock and Snow in the Pacific Northwest"
date: 2012-04-29T11:42:05-04:00
draft: true
categories: ["Outdoors"]
type: "post"
image: "/Smith.jpg"
---

It was a strange weekend.

**Vancouver**

We hatched the plan the previous Sunday. I was watching football with ex-VOCer Alex Thompson, bored and rained out for the weekend. Sustained rain had ended the Squamish climbing season, and with reliable skiing still months away we were looking for creative ways to fill the gap. Unable to reach a consensus, Alex suggested an adventure tournament – that each of us was to nominate eight potential weekend trips to do battle in a single elimination bracket. Each day that week we emailed votes to each other, soliciting tiebreaking help from our friends. Thursday’s vote gave the win to exploring Portland on Saturday and climbing Mt. St. Helens on Sunday, narrowly edging out a weekend climbing trip to Smith Rock, Oregon.

Plans changed on Friday when a Special Weather Statement (whatever that means) was released, forecasting cold, hard and sustained rain all across the coast. Concerned about a miserable weekend, I went over to Alex’s at lunch to discuss. We thought we could dodge the weather if we went inland, and that St. Helens was gentle enough to climb in the rain. We decided to climb at Smith Rock on Saturday, then head back to St. Helens for Sunday. Somehow severe weather made our plans more ambitious. Insidious Alex has a habit of doing that. We packed immediately and were on the road at 3, crossing the border and rolling into Smith Rock at 2 a.m. after battling heavy rain most of the way.

**Smith Rock, Oregon**

Strong winds made for a fitful sleep, but we woke to the sun we were hoping for. I think I have a soft spot for the desert, or maybe Smith Rock really is that beautiful. Either way I felt fresh and excited for the day. We came hoping to do some multipitch climbing, and chose to climb Moscow. This four star trad route was one of the first lines up Smith Rock, done in 1965. It clocks in at four pitches and an old school 5.6.

{{<figure src="/Smith.jpg" caption="Morning sun on Smith Rock.  Moscow climbs the shadowy buttress on the right of the main formation"  >}}

When we arrived at the base of the route there were two parties of three already en route. We were a bit concerned about their pace, but Alex is relatively new to multipitch climbing so I didn’t think we’d be too speedy ourselves. It turned out that the first party of three was slow slow, with one leader dragging along two inexperienced climbers, one of whom broke into tears on pitch two. I tried to offer some encouragement, and she eventually made it up the wall and seemed pretty happy up top. We killed time at belays chatting about the adventures of our friends Lindsay and Greg who are on an extended cycle tour through Eastern Europe (stop reading this trip report and go check out their [blog](http://lindsayandgreg.wordpress.com)!)

{{<figure src="/Alex on Moscow.jpg" caption="Alex, enjoying the second pitch of Moscow"  >}}

The climbing was moderate and enjoyable, taking a very steep line for 5.6. Building belays was substantially trickier than your typical Squamish route, especially given my single rack. Make sure your anchor theory is fresh before climbing multipitches at Smith! The highlight of the climb for me was 25 feet of unexpected offwidth corner to gain the summit, consistent at 4 inches wide. The biggest piece on my rack is a single 3 inch cam, and I had to choose between placing it well at the bottom of the offwidth, or very poorly partway up. I chose the former (in hindsight an obvious decision) and grunted up the spicy runout without incident.

We topped out, snapped a photo and wandered around the top to show Alex the Monkey (not a euphemism). Hoping to climb a few more single pitches before it got dark, we wandered around to the front side of the formation and found an absolute throng of climbers. The number of harnesses with eight draws, a gri-gri and a lead belay card suggested that Smith is a popular destination for the city gym crowd. It was far too busy to hop on any sport route easier than 5.13, so we found a four star 5.9 dihedral sitting completely unoccupied to wrap up the day. Strangely, we drove 10 hours to the birthplace of North American sport climbing and didn’t clip a single bolt. It was just that kind of trip.

**Mount St. Helens, Washington**

From Smith Rock we left for St. Helens, intending to camp near the base to allow an early start. Darkness and heavy snow through the Mt Hood pass turned what we expected to be three hours of driving into six. We neared St. Helens and searched in vain for a campsite that didn’t want to be found. Exhausted and anxious for the day ahead, we grew cantankerous. We gave up the search around 1 a.m. and pulled over to poach 5 hours of sleep off the side of the highway. We woke, picked up permits in town and drove to the trailhead.

Mount St. Helens is and was an active volcano. It erupted in 1980, killing 57 in the worst volcanic event in US history. From a climbers perspective the eruption domesticated the mountain, lopping 400m off the summit and leaving a gentler gradient on all slopes. What was once a genuine mountaineering objective is now an achievable goal for the ambitious tourist; the summer route sees up to 100 ascents per day. The high novelty and relatively low difficulty appealed to us.

We knew we were in for more than a wet hike upon arriving at the parking lot. The two inches of snow at 1100m promised much more accumulation at the 2500m summit. We would later learn that the weather system from the Special Weather Statement had dumped over a foot of snow on the mountain in the past two days. We were well equipped and excited all the same, and set off undeterred. Just above the tree line we met a ranger who said a further 6 inches of snow would fall that day and my 2WD car might not make it out of the lot. We briefly considered turning back, but the Beattiemobile has good tires and a courageous heart, so we resolved to climb quickly and pressed forward.

Above the tree line the ridge is lined with volcanic rubble, ranging from football to car sized blocks. High winds had deposited snow on the ridge and formed bridges between the blocks. While the boulders provided valuable contrast in whiteout conditions, negotiating the terrain required special care to not step through a snow bridge and land awkwardly on a rock below. Alex carefully led us through the first third of the route, where we drank and switched places.
{{<figure src="/Alex on Monitor.jpg" caption="Alex, low on Monitor Ridge"  >}}

Shortly after switching we passed the party breaking trail through the fresh snow. I thanked them for their work and started setting my own line. The ridge offered either shin deep snow or scrambling over the rubble. Pushing through the snow was more tiring, but scrambling on slippery blocks was more dangerous so I chose a mixture of both. As we pushed past the halfway point, shin deep turned to knee deep, knee deep turned to thigh deep, and some points had me up to my hips. Wind loading had dumped a ton of snow on the ridge. Winter had come to St. Helens. I climbed with some difficulty through to about 2000m, where the rubble disappeared and wind had swept away the snow, leaving a crunchy surface of rime underneath. We gained elevation quickly as high wind buffeted our shells. By this point Alex’s gloves had frozen into solid blocks and he was well into Type 2 fun. We climbed to what we made out to be the summit in near whiteout, snapped photos and turned around.

{{<figure src="/Monitor.jpg" caption="Monitor Ridge. Deep snow made for strenuous postholing and a good sense of adventure"  >}}
Monitor Ridge pales in comparison to the typical VOC mountaineering caper. Any illusions of machismo I had were quickly dispelled as we descended past large groups of climbers in all states of preparedness. That said, this was big for us. Our previous winter experience in the mountains was limited to some pretty tame ski touring. Climbing St. Helens felt different, especially when I was breaking trail. I felt very small against the mountain. Despite the wind it felt lonely and calm. I enjoyed it very much.

We descended with care and got back to the lot at 2 p.m., six hours car to car. The road was in good shape and the drive back to Vancouver was pleasant.

{{<figure src="/Snowy Alex.jpg" caption="An icy Alex, happy to be off the exposed ridge"  >}}

I’m not sure what to make of this trip now that it’s done. On one hand, we drove 1700 km over 54 hours. That is a fundamentally stupid thing to do. On the other hand, we dodged the coastal rain for a weekend and snagged two summits. One looked like this:

{{<figure src="/Summit 1.jpg" caption="Saturday afternoon, atop Red Wall at Smith Rock"  >}}

The other looked like this:

{{<figure src="/Summit 2.jpg" caption="Sunday afternoon, at the true (?) summit of Mount St. Helens"  >}}
