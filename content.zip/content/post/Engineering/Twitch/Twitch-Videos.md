---
title: "Twitch Videos"
date: 2018-04-03T22:51:12-04:00
draft: true
categories: ["Engineering"]
tags: ["Twitch"]
---

A collection of footage taken of and from the driving robot. This isn't the easiest robot to handle in the world, so prepare to see some lousy driving.

{{<youtube id="4eR07FtCMLg" caption="test">}}

{{<youtube 3JtDmztKQi8>}}

{{<youtube mSFlo2-Sf58>}}

{{<youtube T-2AXNRXk-s>}}


