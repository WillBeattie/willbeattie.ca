---
title: "Arts and Crafts"
date: 2018-04-03T21:41:37-04:00
draft: true
type: "category-desc"
image: "/Pentagon - Danish.jpg"
---

Projects in wood and leather

