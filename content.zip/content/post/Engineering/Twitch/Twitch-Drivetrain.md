---
title: "Twitch Drivetrain"
date: 2018-04-03T22:50:46-04:00
draft: true
categories: ["Engineering"]
tags: ["Twitch"]
---

Twitch is separated from the average four-wheeler by its unusual drivetrain. This system, detailed below, allows the vehicle to drift and to change the orientation of its wheels, both of which make for silly and fun driving.

{{< youtube m2gshdkTewM >}}
A walk through of the drivetrain

We have four independently driven wheels, each mounted on pegs that allow them to rotate about the z-axis. I could have driven this rotation with a servo-motor for each wheel, but that seemed excessive. If all you want to do is swap the wheels between forward-and-back and left-and-right orientations, then you'll notice that each wheel needs to turn 90 degrees, but each wheel needs to turn in the opposite direction from its neighbors. By connecting wheels at opposite corners with a linkage, we can cut the number of servos required from four down to two.

{{<figure src="/Linkage Explained.png" caption="Showing the parallelogram formed between the revolute joints in our robot, without the linkages(left) and with them (right). Notice that even though the linkages aren't straight, the parallelogram is unchanged. What matters is the location of the joints!">}}


I produced the linkage bars from 1/8" aluminum cut by waterjet. They're attached to the motor assemblies by a shoulder screw, really useful little pieces of hardware for making revolute joints. The product of all this is a four-bar parallelogram linkage, forcing the orientation of opposite wheel assemblies to always be equal.


{{<figure src="/Shoulder screw.png" caption="Shoulder screws, remarkably holding in a self-tapped hole in UHMW"  >}}

The components I used for the drive and linkage assemblies are almost identical to Shane's, as he found a nice combination of products small enough to fit inside the sandwich and powerful enough to actually work.

*   Motors: [BaneBots RS380](http://banebots.com/pc/MOTOR-BRUSH/M3-RS380-72), a 7.2V nominal brushed DC motor
*   Gearboxes: [BaneBots P60](http://banebots.com/pc/P60K-S5/P60K-55-0004), a 26:1 planetary gearbox
*   Drive assembly blocks: These pieces sandwich the gearbox and serve as the interface between the drive assemblies and the robot frame. They're made from Ultra-high molecular weight polyethylene (UHMW), a slippery plastic.
*   Wheels: [Vex 4" Omni Wheel"](http://www.vexrobotics.com/omni-wheels.html)
*   Hubs: [Vex VersaHub](http://www.vexrobotics.com/versahubs.html), 1/2" round w/ 1/8" keyway. I'm glad these things exist as I wasn't looking forward to trying to machine a substitute.
*   Shoulder screws: [Here](https://www.fastenal.com/products/details/0175669) Remarkably, these hold pretty well in the UHMW blocks despite having only 1/8" of thread in plastic.
*   Servos: [Vigor VS-11](http://www.hobbyking.com/hobbyking/store/__16643__VS_11_Vigor_Extra_Large_Servo_19sec_19kg_103g.html), a beefy servo with almost 2 Nm stall torque