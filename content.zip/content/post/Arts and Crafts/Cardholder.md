---
title: "Cardholder Pattern"
date: 2012-02-03T22:29:17-04:00
draft: true
categories: ["Arts and Crafts"]
tags: ["Leatherworking"]
image: "/Cardholder.jpg"
desc: "A simple cardholder pattern"
---

The simplest and most popular design I've made so far is my little card holder wallet.

{{<figure src="/Cardholder.jpg#center"  >}}

The cardholders fit 2-3 cards in each of the two slots and bills in the main body. It is made from four simple pieces and is totally planar, so construction is a breeze. And best of all it's small and thin enough for someone with larger-than-normal legs like myself to comfortably slip into a front pocket.

Reverse engineering one of these things wouldn't be too difficult (in fact, I first ripped the design off of the [Journeyman wallet](http://www.tannergoods.com/collections/wallets/products/journeyman-5) from the excellent [Tanner Goods](http://www.tannergoods.com/)). That said, in the name of saving effort I put together a pattern for this project.

{{<figure src="/Pattern.JPG#center"  >}}

Click [here](/Cardholder Pattern.pdf) to download a .pdf for printing

Probably the easiest way to use this is to grab the .pdf pattern by clicking the image above, printing it at 1:1 (not fit to page!) and then cutting out the pattern pieces to use as templates on your leather. After prepping the leather (dyeing and finishing the pieces, beveling and burnishing the internal edges) glue them in place and then mark a line 3/16" away from the project edge. Sew at ~5mm/stitch, looping over the top of the project to start and finish the stitch. Bevel and burnish the exterior edge and you're done!

{{<figure src="/Cardholders.jpg#center" caption="Cardholders dyed with Fiebing's Light Brown, Tan (back), Medium Brown, and Navy (front)"  >}}