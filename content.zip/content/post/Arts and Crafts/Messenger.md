---
title: "Nigel Armitage Messenger Bag"
date: 2012-06-12T22:29:25-04:00
draft: true
categories: ["Arts and Crafts"]
tags: ["Leatherworking"]
status: "Complete"
image: "/064.jpg"
desc: "A latigo messenger bag with a creepy lining"
---

This project was my first bag. I had wanted to scale up to larger projects for a while, but the increased complexity and size intimidated me a little. The solution was to follow a pattern, specifically this [Nigel Armitage messenger bag](https://www.youtube.com/watch?v=nEwbvfsZfBw) how to on Youtube. If you Paypal him $10 he'll reply with a design document that takes a lot of the stress of your back. I was happy to do so and pleasantly surprised with the result.

{{<figure src="/062.jpg#center" caption="Front view. The distortion you see in the main body is from the chunky book I was carrying at the time"  >}}

I made a few small changes to his design, electing for a different closure and choosing to line the bag with fabric.

{{<figure src="/064.jpg#center" caption="Showing the super creepy elk of doom lining"  >}}

The closure was something I picked up off the shelf at a local Vancouver leather shop, [Lonsdale Leather](http://www.lonsdaleleather.com/). Helpful folks there. I really like the metal on metal look of it, and the closure mechanism is fun to play with, snapping satisfyingly into place.

{{<figure src="/071.jpg#center" caption="Rear view. In hindsight I'm not sure how useful this rear pocket actually is. Anything bulky shoved in there would cause the bag to lie awkwardly against your body."  >}}

**Details:**

*   Style: Book-bag, one flap, one gusset, one back pocket, one interior pocket
*   Leather: 5-6 oz Horoween Chromexcel (I think?). I wish I had 6-7oz to use for the main body and strap and 3-4oz to use for the pockets and gusset, but this worked well enough
*   Dimensions: Roughly 8" x 11" x 1.5". Holds a tablet or a novel nicely, but it doesn't quite fit a sheet of paper
*   Thread: [0.035" Maine Waxed Cord in Brown](http://www.mainethread.com/product9.html)
*   Lining: Cotton. Unfortunately it looks like the supplier has discontinued this particular pattern
