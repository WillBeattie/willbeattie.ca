---
title: "Hot Wire Cutter"
date: 2018-05-09T20:53:41-04:00
draft: true
type: "post"
desc: "A quick and dirty hot-wire tool for cutting foam"
image: "/cutter.jpg"
status: "Complete"
categories: ["Small Projects"]
---


Medavail's machines perform a variety of package handling tasks, one of which is applying labels.  'John Smith, Acetaminophen, Take Twice Daily with Water,' you know the ones.   

To get the labels to conform to their package we squish them with a foam block, cut into a shape that (hopefully) forces the label to wrap over edges and curves of the package.  I recently wanted to test out some concepts for new foam block shapes but didn't want to spend time and money getting them waterjet (their normal method of manufacture), so I made a tool for 'cutting' foam.  

A hot-wire cutter is an tool featuring a single wire held under tension and heated with an electric current until its hot enough to melt through foam, giving the appearance of cutting your workpiece.  If you have a benchtop power supply it's really easy to build - I used scrap wood and metal and a 0.012" tin-plated steel guitar string as the cutter.  If you have a thin gage [nichrome wire](https://en.wikipedia.org/wiki/Nichrome) (the wire material most commonly used in heating elements) you should use that instead.  

A scrap piece of bent steel sheet holds the top of the wire ~4" above the platform base.  The bottom of the wire is anchored through a bolt which gets screwed into a nut in the base.  Tightening the nut gradually increases the tension on the wire which helps keep it straight and taut.

{{<figure src="/cutter-design.JPG" caption="The hot-wire cutter.  The wood block on bottom has a counterbored hole (red) that houses a machine screw (blue) that threads into a nut below.  The screw has a hole drilled along its axis through which the cutting wire (black) passes.  To tension the wire you crank the nut, forcing the screw down.  Ugly, but free!">}}

To hook the cutter up to the supply I just took some leads with alligator clips and attached one end to the sheet metal and the other to the nut at the bottom of the cutting wire.

**Warm Up**

The whole hot-wire cutter is basically just one giant short circuit.  When you flip on your power supply there's a good chance its built in current limiting fault will kick in, especially if you're using guitar string as opposed to nichrome, which has higher resistance.  Now the nice thing here is that the resistance of most metals increases with temperature (kinda sorta linearly, for generous definitions of linearly).  So the trick here is to turn on your supply starting at 0V and slowly crank it up, watching the ammeter as you go.  As the wire heats up the resistance goes up, so if you're careful you can increase the voltage without increasing the current through the circuit.  I end up operating this cutter around ~5V, ~1A, which gives ~5W dumped into the wire.  You can't cut thick materials continuously at these settings though, since the wire cools down too fast.  A slightly thicker nichrome wire and a higher power circuit would help this issue.

{{<figure src="/cutter-circuit.jpg" caption="The model circuit, an adjustable voltage source drives current through a resistor (cutting wire) whose resistance is a function of temperature">}}

**Don't die**

Many commercial foam products contain chlorine in their chemistry and produce nasty gases when burned or vaporized.  If you are at all uncertain about the contents of the smoke that emerges from your workpiece when cutting you need to pay careful attention to ventilation.  I use this setup with a fan at my back blowing out our shipping/receiving port and I avoid inhaling anywhere near the cutter while it's working.

{{<figure src="/cutter.jpg" caption="Cutting a piece.  The dimensional control is inarguably poor, but it was sufficient for prototyping">}}